# ChatGPT Clone

Production-ready full-stack ChatGPT clone.

## Stack

- **Frontend:** Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **Backend:** Next.js API Routes + Vercel AI SDK (streaming)
- **AI:** OpenAI GPT-4o-mini (swap via `@ai-sdk/openai`)
- **Auth/DB (optional):** Supabase

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env.local
# Edit .env.local with your OPENAI_API_KEY

# 3. Run dev server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Production Deployment

### Vercel (recommended)

```bash
npm i -g vercel
vercel
```

Set `OPENAI_API_KEY` in Vercel dashboard → Settings → Environment Variables.

### Docker

```bash
docker build -t chatgpt-clone .
docker run -p 3000:3000 -e OPENAI_API_KEY=sk-xxx chatgpt-clone
```

## Project Structure

```
src/
├── app/
│   ├── api/chat/route.ts   # Streaming chat endpoint
│   ├── globals.css         # Tailwind styles
│   ├── layout.tsx          # Root layout
│   └── page.tsx            # Chat UI
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `OPENAI_API_KEY` | ✅ | OpenAI API key |
| `NEXT_PUBLIC_SUPABASE_URL` | ❌ | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | ❌ | Supabase anon key |
