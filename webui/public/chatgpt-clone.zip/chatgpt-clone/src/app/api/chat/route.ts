import { openai } from '@ai-sdk/openai';
import { streamText } from 'ai';
import { z } from 'zod';

const envSchema = z.object({
  OPENAI_API_KEY: z.string().min(1),
});

export async function POST(req: Request) {
  // Validate env
  const parsed = envSchema.safeParse(process.env);
  if (!parsed.success) {
    return new Response(
      JSON.stringify({ error: 'Missing OPENAI_API_KEY' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }

  const { messages } = await req.json();

  const result = streamText({
    model: openai('gpt-4o-mini'),
    messages,
  });

  return result.toDataStreamResponse();
}
